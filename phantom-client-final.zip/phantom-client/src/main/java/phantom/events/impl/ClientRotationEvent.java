package phantom.events.impl;
public class ClientRotationEvent {
    public float yaw, pitch;
    private boolean cancelled;
    public ClientRotationEvent(float yaw, float pitch) { this.yaw = yaw; this.pitch = pitch; }
    public boolean isCancelled() { return cancelled; }
    public void cancel() { cancelled = true; }
}
