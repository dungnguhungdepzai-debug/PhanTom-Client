package phantom.events.impl;
public class KeyInputEvent {
    public final int key, action, mods;
    public KeyInputEvent(int key, int action, int mods) { this.key = key; this.action = action; this.mods = mods; }
}
