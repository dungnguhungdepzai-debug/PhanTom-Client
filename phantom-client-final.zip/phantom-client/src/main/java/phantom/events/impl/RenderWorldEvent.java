package phantom.events.impl;
public class RenderWorldEvent {
    public final Object matrices;
    public final float delta;
    public RenderWorldEvent(Object matrices, float delta) { this.matrices = matrices; this.delta = delta; }
    public static class Post extends RenderWorldEvent {
        public Post(Object matrices, float delta) { super(matrices, delta); }
    }
}
