package phantom.events.impl;
public class AttackEntityEvent {
    private final Object target;
    private boolean cancelled;
    public AttackEntityEvent(Object target) { this.target = target; }
    public Object getTarget() { return target; }
    public boolean isCancelled() { return cancelled; }
    public void cancel() { cancelled = true; }
}
