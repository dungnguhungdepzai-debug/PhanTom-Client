package phantom.events.impl;
public class UpdateVelocityEvent {
    public double x, y, z;
    public UpdateVelocityEvent(double x, double y, double z) { this.x = x; this.y = y; this.z = z; }
}
