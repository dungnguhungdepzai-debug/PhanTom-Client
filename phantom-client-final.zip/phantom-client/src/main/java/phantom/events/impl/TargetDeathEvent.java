package phantom.events.impl;
import net.minecraft.entity.Entity;
public class TargetDeathEvent {
    public final Entity entity;
    public TargetDeathEvent(Entity entity) { this.entity = entity; }
}
