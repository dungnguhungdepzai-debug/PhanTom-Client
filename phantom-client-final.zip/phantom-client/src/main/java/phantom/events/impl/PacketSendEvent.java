package phantom.events.impl;
public class PacketSendEvent {
    private final Object packet;
    private boolean cancelled;
    public PacketSendEvent(Object packet) { this.packet = packet; }
    public Object getPacket() { return packet; }
    public boolean isCancelled() { return cancelled; }
    public void cancel() { cancelled = true; }
    public static class Post extends PacketSendEvent {
        public Post(Object packet) { super(packet); }
    }
}
