package phantom.events.impl;
public class PlayerDeathEvent {}
