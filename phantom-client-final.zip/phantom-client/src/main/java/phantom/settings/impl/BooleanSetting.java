package phantom.settings.impl;
import phantom.settings.Setting;

public class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String name, boolean defaultValue) {
        super(name, defaultValue);
    }
    public boolean isEnabled() { return value; }
    public void toggle() { value = !value; }
    @Override public String getValueString() { return value ? "ON" : "OFF"; }
}
