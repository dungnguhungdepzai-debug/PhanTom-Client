package phantom.settings.impl;
import phantom.settings.Setting;

public class StringSetting extends Setting<String> {
    public StringSetting(String name, String defaultValue) {
        super(name, defaultValue);
    }
    @Override public String getValueString() { return value; }
}
