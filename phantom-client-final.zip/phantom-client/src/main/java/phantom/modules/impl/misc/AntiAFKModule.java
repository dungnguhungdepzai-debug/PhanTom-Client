package phantom.modules.impl.misc;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.ModeSetting;
import java.util.List;
public class AntiAFKModule extends Module {
    private final ModeSetting mode=addSetting(new ModeSetting("Mode","Rotate",List.of("Rotate","Jump","Swing")));
    private int tickCount=0;
    public AntiAFKModule(){super("AntiAFK","Prevents AFK kick.",Module.Category.MISC,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null)return;
        tickCount++;
        if(tickCount%100==0){
            switch(mode.getValue()){
                case "Rotate"->mc.player.setYaw(mc.player.getYaw()+30);
                case "Jump"->{ if(mc.player.isOnGround()) mc.player.jump(); }
                case "Swing"->mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            }
        }
    }
}