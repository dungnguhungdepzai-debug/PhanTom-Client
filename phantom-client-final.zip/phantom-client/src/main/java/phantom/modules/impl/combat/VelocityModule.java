package phantom.modules.impl.combat;

import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.PacketSendEvent;
import phantom.events.impl.UpdateVelocityEvent;
import phantom.modules.Module;
import phantom.settings.impl.ModeSetting;
import phantom.settings.impl.NumberSetting;

import java.util.List;

public class VelocityModule extends Module {

    private final ModeSetting   mode      = addSetting(new ModeSetting  ("Mode",    "Reduce", List.of("Cancel","Reduce","Reverse")));
    private final NumberSetting horizontal = addSetting(new NumberSetting("Horizontal", 0.35, 0.0, 1.0, 0.05));
    private final NumberSetting vertical   = addSetting(new NumberSetting("Vertical",   1.0,  0.0, 1.0, 0.05));

    public VelocityModule() {
        super("Velocity", "Modifies knockback received from attacks.", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @SubscribeEvent
    public void onVelocity(UpdateVelocityEvent e) {
        if (mc.player == null || mc.player.hurtTime <= 0) return;

        double hFactor = switch (mode.getValue()) {
            case "Cancel"  -> 0.0;
            case "Reduce"  -> horizontal.getValue();
            case "Reverse" -> -horizontal.getValue();
            default        -> 1.0;
        };
        double vFactor = vertical.getValue();

        e.x *= hFactor;
        e.z *= hFactor;
        e.y *= vFactor;
    }
}
