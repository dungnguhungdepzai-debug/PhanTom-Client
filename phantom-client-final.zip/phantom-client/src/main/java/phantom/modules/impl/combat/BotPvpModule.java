package phantom.modules.impl.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.item.AxeItem;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
import phantom.settings.impl.ModeSetting;
import phantom.settings.impl.NumberSetting;

import java.util.*;

/**
 * BotPvP — full auto combat bot
 * Tự tìm target → tiếp cận → đánh → strafe → dodge KB → auto item
 */
public class BotPvpModule extends Module {

    // --- settings ---
    private final ModeSetting   targetPriority = addSetting(new ModeSetting("Priority",  "Closest",   List.of("Closest","LowHP","HighHP")));
    private final NumberSetting engageRange    = addSetting(new NumberSetting("Engage Range", 16.0, 2.0, 32.0, 1.0));
    private final NumberSetting attackRange    = addSetting(new NumberSetting("Attack Range",  3.8, 1.0,  6.0, 0.1));
    private final NumberSetting strafeRange    = addSetting(new NumberSetting("Strafe Range",  2.5, 1.0,  5.0, 0.1));
    private final NumberSetting minCPS         = addSetting(new NumberSetting("Min CPS",        8.0, 1.0, 20.0, 1.0));
    private final NumberSetting maxCPS         = addSetting(new NumberSetting("Max CPS",       12.0, 1.0, 20.0, 1.0));
    private final BooleanSetting autoStrafe    = addSetting(new BooleanSetting("Auto Strafe",   true));
    private final BooleanSetting autoApproach  = addSetting(new BooleanSetting("Auto Approach", true));
    private final BooleanSetting antiKB        = addSetting(new BooleanSetting("Anti KB",       true));
    private final BooleanSetting autoWeapon    = addSetting(new BooleanSetting("Auto Weapon",   true));
    private final BooleanSetting autoTotem     = addSetting(new BooleanSetting("Auto Totem",    true));
    private final BooleanSetting autoPot       = addSetting(new BooleanSetting("Auto Pot",      true));
    private final NumberSetting potHP          = addSetting(new NumberSetting("Pot HP",         14.0, 1.0, 20.0, 0.5));
    private final BooleanSetting jumpCrit      = addSetting(new BooleanSetting("Jump Crit",     true));
    private final ModeSetting   strafeMode     = addSetting(new ModeSetting("Strafe Mode", "Circle", List.of("Circle","Jitter","None")));

    // --- state ---
    private PlayerEntity target      = null;
    private long         lastAttack  = 0;
    private float        strafeAngle = 0f;
    private int          strafeDir   = 1;
    private int          strafeTick  = 0;
    private final Random rng         = new Random();

    // bot state machine
    private enum BotState { IDLE, APPROACH, COMBAT, RETREAT }
    private BotState state = BotState.IDLE;

    public BotPvpModule() {
        super("BotPvP", "Full auto combat bot — moves, attacks, strafes autonomously.", Category.COMBAT, GLFW.GLFW_KEY_UNKNOWN);
    }

    @Override
    public void onEnable() {
        target = null;
        state  = BotState.IDLE;
        strafeAngle = 0f;
    }

    @Override
    public void onDisable() {
        // Stop all movement input
        if (mc.player != null) {
            mc.player.setVelocity(mc.player.getVelocity().x * 0.1, mc.player.getVelocity().y, mc.player.getVelocity().z * 0.1);
        }
        target = null;
        state  = BotState.IDLE;
    }

    @SubscribeEvent
    public void onTick(TickEvent e) {
        if (mc.player == null || mc.world == null) return;

        // --- step 1: find target ---
        target = findTarget();
        if (target == null) { state = BotState.IDLE; return; }

        double dist = mc.player.distanceTo(target);

        // --- step 2: determine state ---
        if (dist > engageRange.getValue()) {
            state = BotState.IDLE;
            return;
        } else if (dist > attackRange.getValue() + 0.5) {
            state = BotState.APPROACH;
        } else {
            state = BotState.COMBAT;
        }

        // --- step 3: face target ---
        faceTarget(target);

        // --- step 4: state actions ---
        switch (state) {
            case APPROACH -> handleApproach(target, dist);
            case COMBAT   -> handleCombat(target, dist);
            default       -> {}
        }

        // --- step 5: utility ---
        if (autoWeapon.isEnabled()) selectBestWeapon();
        if (autoTotem.isEnabled())  equipTotem();
        if (autoPot.isEnabled()&&mc.player.getHealth()<potHP.getValue()) throwPot();
    }

    // ---------------------------------------------------------------
    // TARGET SELECTION
    // ---------------------------------------------------------------
    private PlayerEntity findTarget() {
        List<PlayerEntity> candidates = new ArrayList<>();
        for (Entity ent : mc.world.getEntities()) {
            if (!(ent instanceof PlayerEntity p)) continue;
            if (p == mc.player) continue;
            if (p.isDead() || p.getHealth() <= 0) continue;
            if (mc.player.distanceTo(p) > engageRange.getValue()) continue;
            candidates.add(p);
        }
        if (candidates.isEmpty()) return null;

        return switch (targetPriority.getValue()) {
            case "LowHP"  -> candidates.stream().min(Comparator.comparingDouble(PlayerEntity::getHealth)).orElse(null);
            case "HighHP" -> candidates.stream().max(Comparator.comparingDouble(PlayerEntity::getHealth)).orElse(null);
            default       -> candidates.stream().min(Comparator.comparingDouble(p -> mc.player.distanceTo(p))).orElse(null);
        };
    }

    // ---------------------------------------------------------------
    // APPROACH — move toward target
    // ---------------------------------------------------------------
    private void handleApproach(PlayerEntity tgt, double dist) {
        if (!autoApproach.isEnabled()) return;

        double dx = tgt.getX() - mc.player.getX();
        double dz = tgt.getZ() - mc.player.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.001) return;

        double speed = 0.28;
        double vx = (dx / len) * speed;
        double vz = (dz / len) * speed;

        mc.player.setVelocity(vx, mc.player.getVelocity().y, vz);
        mc.player.setSprinting(true);

        // jump over obstacles
        if (mc.player.horizontalCollision && mc.player.isOnGround()) {
            mc.player.jump();
        }
    }

    // ---------------------------------------------------------------
    // COMBAT — attack + strafe
    // ---------------------------------------------------------------
    private void handleCombat(PlayerEntity tgt, double dist) {
        // attack
        long now   = System.currentTimeMillis();
        double cps = minCPS.getValue() + rng.nextDouble() * (maxCPS.getValue() - minCPS.getValue());
        long delay = (long)(1000.0 / cps);

        if (now - lastAttack >= delay) {
            // jump crit
            if (jumpCrit.isEnabled() && mc.player.isOnGround() && !mc.player.isSneaking()) {
                mc.player.jump();
            }
            mc.player.attack(tgt);
            mc.player.swingHand(Hand.MAIN_HAND);
            lastAttack = now;
        }

        // strafe
        if (autoStrafe.isEnabled()) handleStrafe(tgt, dist);

        // anti knockback
        if (antiKB.isEnabled() && mc.player.hurtTime > 0) {
            var vel = mc.player.getVelocity();
            mc.player.setVelocity(vel.x * 0.35, vel.y, vel.z * 0.35);
        }
    }

    // ---------------------------------------------------------------
    // STRAFE LOGIC
    // ---------------------------------------------------------------
    private void handleStrafe(PlayerEntity tgt, double dist) {
        strafeTick++;

        // switch direction randomly every 20-40 ticks
        if (strafeTick > 20 + rng.nextInt(20)) {
            strafeDir = -strafeDir;
            strafeTick = 0;
        }

        switch (strafeMode.getValue()) {
            case "Circle" -> circleStrafe(tgt, dist);
            case "Jitter" -> jitterStrafe(tgt);
        }

        mc.player.setSprinting(true);
    }

    private void circleStrafe(PlayerEntity tgt, double dist) {
        strafeAngle += strafeDir * 4.5f;
        double rad = Math.toRadians(strafeAngle);

        double targetDist = strafeRange.getValue();
        double cx = tgt.getX() + Math.cos(rad) * targetDist;
        double cz = tgt.getZ() + Math.sin(rad) * targetDist;

        double dx = cx - mc.player.getX();
        double dz = cz - mc.player.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 0.001) return;

        double speed = 0.26;
        mc.player.setVelocity((dx / len) * speed, mc.player.getVelocity().y, (dz / len) * speed);

        // jump if blocked
        if (mc.player.horizontalCollision && mc.player.isOnGround()) mc.player.jump();
    }

    private void jitterStrafe(PlayerEntity tgt) {
        // random micro-movement
        double jx = (rng.nextDouble() - 0.5) * 0.4;
        double jz = (rng.nextDouble() - 0.5) * 0.4;

        // bias toward target
        double dx = tgt.getX() - mc.player.getX();
        double dz = tgt.getZ() - mc.player.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len > 0.001) {
            jx += (dx / len) * 0.1 * strafeDir;
            jz += (dz / len) * 0.1 * strafeDir;
        }

        var vel = mc.player.getVelocity();
        mc.player.setVelocity(vel.x + jx, vel.y, vel.z + jz);
    }

    // ---------------------------------------------------------------
    // ROTATION — silent face target
    // ---------------------------------------------------------------
    private void faceTarget(PlayerEntity tgt) {
        double dx = tgt.getX() - mc.player.getX();
        double dy = (tgt.getY() + tgt.getHeight() * 0.5) - (mc.player.getY() + mc.player.getEyeHeight());
        double dz = tgt.getZ() - mc.player.getZ();
        double dist2d = Math.sqrt(dx * dx + dz * dz);

        float yaw   = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist2d)));

        // smooth rotation
        float diffYaw   = MathHelper.wrapDegrees(yaw   - mc.player.getYaw());
        float diffPitch = MathHelper.wrapDegrees(pitch - mc.player.getPitch());
        float speed = 35f;

        mc.player.setYaw  (mc.player.getYaw()   + MathHelper.clamp(diffYaw,   -speed, speed));
        mc.player.setPitch(mc.player.getPitch() + MathHelper.clamp(diffPitch, -speed, speed));

        // send rotation packet
        mc.player.networkHandler.sendPacket(
            new PlayerMoveC2SPacket.Full(
                mc.player.getX(), mc.player.getY(), mc.player.getZ(),
                mc.player.getYaw(), mc.player.getPitch(),
                mc.player.isOnGround(), mc.player.horizontalCollision
            )
        );
    }

    // ---------------------------------------------------------------
    // UTILITY
    // ---------------------------------------------------------------
    private void selectBestWeapon() {
        int bestSlot = -1;
        double bestDmg = -1;
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getStack(i);
            double dmg = 0;
            if (stack.getItem() instanceof SwordItem s) dmg = s.getAttackDamage() + 4;
            else if (stack.getItem() instanceof AxeItem a) dmg = a.getAttackDamage() + 4;
            if (dmg > bestDmg) { bestDmg = dmg; bestSlot = i; }
        }
        if (bestSlot != -1) mc.player.getInventory().selectedSlot = bestSlot;
    }

    private void equipTotem() {
        var offhand = mc.player.getOffHandStack();
        if (offhand.getItem() == Items.TOTEM_OF_UNDYING) return;
        for (int i = 9; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
                mc.interactionManager.clickSlot(
                    mc.player.playerScreenHandler.syncId, i, 0,
                    net.minecraft.screen.slot.SlotActionType.PICKUP, mc.player
                );
                mc.interactionManager.clickSlot(
                    mc.player.playerScreenHandler.syncId, 45, 0,
                    net.minecraft.screen.slot.SlotActionType.PICKUP, mc.player
                );
                if (!mc.player.playerScreenHandler.getCursorStack().isEmpty())
                    mc.interactionManager.clickSlot(
                        mc.player.playerScreenHandler.syncId, i, 0,
                        net.minecraft.screen.slot.SlotActionType.PICKUP, mc.player
                    );
                break;
            }
        }
    }

    private void throwPot() {
        for (int i = 0; i < 9; i++) {
            var s = mc.player.getInventory().getStack(i);
            if (s.getItem() == Items.SPLASH_POTION) {
                int prev = mc.player.getInventory().selectedSlot;
                mc.player.getInventory().selectedSlot = i;
                mc.player.networkHandler.sendPacket(
                    new net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket(
                        Hand.MAIN_HAND, mc.player.networkHandler.sequenceNumber,
                        mc.player.getYaw(), mc.player.getPitch()
                    )
                );
                mc.player.getInventory().selectedSlot = prev;
                break;
            }
        }
    }

    public PlayerEntity getCurrentTarget() { return target; }
    public BotState      getBotState()     { return state;  }
}
