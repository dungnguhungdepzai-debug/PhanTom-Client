package phantom.modules.impl.render;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.RenderOverlayEvent;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
import phantom.settings.impl.ModeSetting;
import phantom.Phantom;
import java.util.List;
public class HUDModule extends Module {
    private final BooleanSetting watermark=addSetting(new BooleanSetting("Watermark",true));
    private final BooleanSetting moduleList=addSetting(new BooleanSetting("Module List",true));
    private final BooleanSetting coords=addSetting(new BooleanSetting("Coords",true));
    private final BooleanSetting fps=addSetting(new BooleanSetting("FPS",true));
    private final ModeSetting style=addSetting(new ModeSetting("Style","Default",List.of("Default","Array","Custom")));
    public HUDModule(){super("HUD","Renders on-screen HUD.",Category.RENDER,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onRender(RenderOverlayEvent e){
        if(mc.player==null)return;
        DrawContext ctx=e.context;
        int y=2;
        if(watermark.isEnabled()){
            ctx.drawTextWithShadow(mc.textRenderer,"Phantom v1.0",2,y,0xFF9966FF); y+=10;
        }
        if(fps.isEnabled()){
            ctx.drawTextWithShadow(mc.textRenderer,"FPS: "+mc.fpsDebugString.split(" ")[0],2,y,0xFFAAAAAA); y+=10;
        }
        if(coords.isEnabled()&&mc.player!=null){
            String c=String.format("XYZ: %.1f / %.1f / %.1f",mc.player.getX(),mc.player.getY(),mc.player.getZ());
            ctx.drawTextWithShadow(mc.textRenderer,c,2,y,0xFFAAAAAA); y+=10;
        }
        if(moduleList.isEnabled()){
            var enabled=Phantom.INSTANCE.moduleManager.getModules().stream().filter(m->m.isEnabled()&&m.isVisible()).toList();
            int rx=ctx.getScaledWindowWidth()-2;
            int ry=2;
            for(var m:enabled){
                int w=mc.textRenderer.getWidth(m.getName());
                ctx.drawTextWithShadow(mc.textRenderer,m.getName(),rx-w,ry,0xFF9966FF); ry+=10;
            }
        }
    }
}