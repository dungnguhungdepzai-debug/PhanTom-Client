package phantom.modules.impl.combat;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.NumberSetting;

public class HoleFillModule extends Module {
    private final NumberSetting range=addSetting(new NumberSetting("Range",4.5,1.0,8.0,0.5));
    public HoleFillModule(){super("HoleFill","Fills holes enemies are hiding in.",Category.COMBAT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null||mc.world==null)return;
        int obsSlot=findObsidian(); if(obsSlot==-1)return;
        for(var ent:mc.world.getEntities()){
            if(!(ent instanceof PlayerEntity p)||p==mc.player)continue;
            if(mc.player.distanceTo(p)>range.getValue())continue;
            BlockPos hole=p.getBlockPos().down();
            if(!mc.world.getBlockState(hole).isAir())continue;
            int prev=mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot=obsSlot;
            mc.player.networkHandler.sendPacket(new net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket(
                Hand.MAIN_HAND,new BlockHitResult(Vec3d.ofCenter(hole.down()),Direction.UP,hole.down(),false),
                mc.player.networkHandler.sequenceNumber));
            mc.player.getInventory().selectedSlot=prev;
        }
    }
    private int findObsidian(){
        for(int i=0;i<9;i++) if(mc.player.getInventory().getStack(i).getItem()==Items.OBSIDIAN)return i;
        return-1;
    }
}
