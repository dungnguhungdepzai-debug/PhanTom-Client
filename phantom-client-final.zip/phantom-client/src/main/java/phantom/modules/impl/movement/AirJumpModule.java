package phantom.modules.impl.movement;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.NumberSetting;
public class AirJumpModule extends Module {
    private final NumberSetting jumps=addSetting(new NumberSetting("Jumps",2.0,1.0,5.0,1.0));
    private int cnt=0;
    private boolean wasJumping=false;
    public AirJumpModule(){super("AirJump","Jump in mid-air.",Category.MOVEMENT,GLFW.GLFW_KEY_UNKNOWN);}
    @Override public void onEnable(){cnt=0;}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null)return;
        if(mc.player.isOnGround()){cnt=0;wasJumping=false;return;}
        boolean j=mc.player.input.playerInput.jump();
        if(j&&!wasJumping&&cnt<(int)jumps.getValue()){mc.player.setVelocity(mc.player.getVelocity().x,0.42,mc.player.getVelocity().z);cnt++;}
        wasJumping=j;
    }
}