package phantom.modules.impl.movement;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.ModeSetting;
import phantom.settings.impl.NumberSetting;
import java.util.List;
public class SpeedModule extends Module {
    private final ModeSetting mode=addSetting(new ModeSetting("Mode","Strafe",List.of("Strafe","Bhop","GrimStrafe")));
    private final NumberSetting speed=addSetting(new NumberSetting("Speed",0.35,0.1,1.5,0.01));
    public SpeedModule(){super("Speed","Increases movement speed.",Category.MOVEMENT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null)return;
        var in=mc.player.input.playerInput;
        if(!in.forward()&&!in.backward()&&!in.left()&&!in.right())return;
        double yaw=Math.toRadians(mc.player.getYaw());
        double s=speed.getValue();
        switch(mode.getValue()){
            case "Bhop"->{ if(mc.player.isOnGround()) mc.player.jump(); s*=1.2; }
            case "GrimStrafe"->{ s*=0.9; if(mc.player.isOnGround()) mc.player.setVelocity(mc.player.getVelocity().x,0.42,mc.player.getVelocity().z); }
        }
        mc.player.setVelocity(-Math.sin(yaw)*s,mc.player.getVelocity().y,Math.cos(yaw)*s);
    }
}