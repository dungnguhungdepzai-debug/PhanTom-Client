package phantom.modules.impl.misc;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.PlayerDeathEvent;
import phantom.modules.Module;
import phantom.settings.impl.NumberSetting;
public class AutoReconnectModule extends Module {
    private final NumberSetting delay=addSetting(new NumberSetting("Delay (s)",3.0,1.0,30.0,1.0));
    public AutoReconnectModule(){super("AutoReconnect","Reconnects after disconnect.",Module.Category.MISC,GLFW.GLFW_KEY_UNKNOWN);}
}