package phantom.modules.impl.render;
import org.lwjgl.glfw.GLFW;
import phantom.modules.Module;
import phantom.settings.impl.ModeSetting;
import java.util.List;
public class ChamModule extends Module {
    private final ModeSetting mode=addSetting(new ModeSetting("Mode","Flat",List.of("Flat","Glow","Wireframe")));
    public ChamModule(){super("Chams","Renders entities through walls with colored model.",Category.RENDER,GLFW.GLFW_KEY_UNKNOWN);}
    public String getMode(){ return mode.getValue(); }
}