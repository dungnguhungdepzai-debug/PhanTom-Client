package phantom.modules.impl.misc;
import org.lwjgl.glfw.GLFW;
import phantom.modules.Module;
public class FastLatencyModule extends Module {
    public FastLatencyModule(){super("FastLatency","Shows a spoofed low ping.",Module.Category.MISC,GLFW.GLFW_KEY_UNKNOWN);}
}