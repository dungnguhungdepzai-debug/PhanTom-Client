package phantom.modules.impl.movement;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
public class NoFallModule extends Module {
    public NoFallModule(){super("NoFall","Prevents fall damage.",Category.MOVEMENT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null||mc.player.isOnGround())return;
        if(mc.player.fallDistance>3f) mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(mc.player.getX(),mc.player.getY(),mc.player.getZ(),true,mc.player.horizontalCollision));
    }
}