package phantom.modules.impl.movement;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
public class SprintModule extends Module {
    private final BooleanSetting omni=addSetting(new BooleanSetting("Omni",true));
    public SprintModule(){super("Sprint","Always sprints.",Category.MOVEMENT,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){ if(mc.player!=null&&(omni.isEnabled()||mc.player.input.playerInput.forward())) mc.player.setSprinting(true); }
}