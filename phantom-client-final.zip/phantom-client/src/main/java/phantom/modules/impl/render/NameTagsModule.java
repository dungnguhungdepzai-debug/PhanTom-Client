package phantom.modules.impl.render;
import org.lwjgl.glfw.GLFW;
import phantom.modules.Module;
import phantom.settings.impl.BooleanSetting;
import phantom.settings.impl.NumberSetting;
public class NameTagsModule extends Module {
    private final BooleanSetting health=addSetting(new BooleanSetting("Health",true));
    private final BooleanSetting ping=addSetting(new BooleanSetting("Ping",false));
    private final NumberSetting scale=addSetting(new NumberSetting("Scale",1.0,0.5,3.0,0.1));
    public NameTagsModule(){super("NameTags","Enhanced player nametags.",Category.RENDER,GLFW.GLFW_KEY_UNKNOWN);}
    public boolean showHealth(){ return isEnabled()&&health.isEnabled(); }
    public double getScale(){ return scale.getValue(); }
}