package phantom.modules.impl.misc;
import org.lwjgl.glfw.GLFW;
import phantom.modules.Module;
public class NoPacketKickModule extends Module {
    public NoPacketKickModule(){super("NoPacketKick","Prevents kick from too many packets.",Module.Category.MISC,GLFW.GLFW_KEY_UNKNOWN);}
}