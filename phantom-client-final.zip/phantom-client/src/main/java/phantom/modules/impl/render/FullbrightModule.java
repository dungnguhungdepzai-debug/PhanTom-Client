package phantom.modules.impl.render;
import org.lwjgl.glfw.GLFW;
import phantom.events.SubscribeEvent;
import phantom.events.impl.TickEvent;
import phantom.modules.Module;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.effect.StatusEffectInstance;
public class FullbrightModule extends Module {
    public FullbrightModule(){super("Fullbright","Makes everything fully lit.",Category.RENDER,GLFW.GLFW_KEY_UNKNOWN);}
    @SubscribeEvent
    public void onTick(TickEvent e){
        if(mc.player==null)return;
        if(!mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)||
            mc.player.getStatusEffect(StatusEffects.NIGHT_VISION).getDuration()<10){
            mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION,Integer.MAX_VALUE,0,false,false));
        }
    }
    @Override public void onDisable(){ if(mc.player!=null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION); }
}