package phantom.managers;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import phantom.Phantom;

import java.util.HashMap;
import java.util.Map;

public class KeybindManager {

    private boolean prevGuiKey = false;
    private final Map<Integer, Boolean> prevKeyState = new HashMap<>();

    public KeybindManager() {
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void onTick(MinecraftClient client) {
        if (client.player == null) return;

        // RightShift opens ClickGui
        boolean guiKey = GLFW.glfwGetKey(client.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (guiKey && !prevGuiKey) {
            if (client.currentScreen == null) {
                client.setScreen(Phantom.INSTANCE.clickGui);
            } else if (client.currentScreen instanceof phantom.gui.ClickGuiScreen) {
                client.setScreen(null);
            }
        }
        prevGuiKey = guiKey;

        // Module keybinds — rising-edge debounce
        if (client.currentScreen != null) return;
        for (var m : Phantom.INSTANCE.moduleManager.getModules()) {
            int key = m.getKeybind();
            if (key == GLFW.GLFW_KEY_UNKNOWN) continue;
            boolean pressed   = GLFW.glfwGetKey(client.getWindow().getHandle(), key) == GLFW.GLFW_PRESS;
            boolean wasPressed = prevKeyState.getOrDefault(key, false);
            if (pressed && !wasPressed) m.toggle();
            prevKeyState.put(key, pressed);
        }
    }
}
