package phantom.managers;

import net.minecraft.client.gui.DrawContext;
import phantom.Phantom;

public class HudManager {
    public void init() {}

    public void render(DrawContext ctx, float delta) {
        if (Phantom.INSTANCE == null || Phantom.INSTANCE.moduleManager == null) return;
        // HUD elements rendered by HUDModule via EventHandler
    }
}
