package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.entity.passive.StriderEntity.class)
public abstract abstract class StriderMixin {}
