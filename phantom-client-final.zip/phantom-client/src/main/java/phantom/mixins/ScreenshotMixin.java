package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.util.ScreenshotRecorder.class)
public abstract abstract class ScreenshotMixin {}
