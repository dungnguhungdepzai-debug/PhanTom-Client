package phantom.mixins.accessors;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.WorldRenderer.class)
public interface LevelRendererAccessor {}
