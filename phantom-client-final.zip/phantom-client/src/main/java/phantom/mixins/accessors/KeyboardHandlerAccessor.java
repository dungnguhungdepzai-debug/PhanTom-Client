package phantom.mixins.accessors;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.Keyboard.class)
public interface KeyboardHandlerAccessor {}
