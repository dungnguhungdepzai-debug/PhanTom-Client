package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.network.PlayerListEntry.class)
public abstract abstract class PlayerListEntryMixin {}
