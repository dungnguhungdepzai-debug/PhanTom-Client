package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.WorldRenderer.class)
public abstract abstract class BlockBreakingInfoMixin {}
