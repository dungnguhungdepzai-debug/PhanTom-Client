package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.gui.screen.Screen.class)
public abstract abstract class ScreenMixin {}
