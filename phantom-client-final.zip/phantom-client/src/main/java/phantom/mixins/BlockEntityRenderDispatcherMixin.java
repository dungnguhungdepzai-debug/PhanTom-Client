package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher.class)
public abstract abstract class BlockEntityRenderDispatcherMixin {}
