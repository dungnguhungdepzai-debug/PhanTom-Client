package phantom.mixins;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import phantom.Phantom;
import phantom.events.impl.PlayerUpdateEvent;
@Mixin(ClientPlayerEntity.class)
public class LocalPlayerMixin {
    @Inject(at=@At("HEAD"), method="tick")
    private void onTickPre(CallbackInfo ci){
        if(Phantom.INSTANCE!=null) Phantom.INSTANCE.eventHandler.dispatchPlayerUpdate();
    }
    @Inject(at=@At("TAIL"), method="tick")
    private void onTickPost(CallbackInfo ci){
        if(Phantom.INSTANCE!=null) Phantom.INSTANCE.eventHandler.dispatchPlayerUpdatePost();
    }
}
