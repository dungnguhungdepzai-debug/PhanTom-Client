package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.DimensionEffects.class)
public abstract abstract class BlindnessFogEnvironmentMixin {}
