package phantom.mixins;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.gui.DrawContext;
import phantom.Phantom;
import phantom.modules.impl.render.NoRenderModule;
@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(at=@At("HEAD"), method="renderVignette", cancellable=true)
    private void onVignette(DrawContext ctx, CallbackInfo ci){
        var mod=Phantom.INSTANCE!=null?Phantom.INSTANCE.moduleManager.get(NoRenderModule.class):null;
        if(mod!=null&&mod.isEnabled()) ci.cancel();
    }
}
