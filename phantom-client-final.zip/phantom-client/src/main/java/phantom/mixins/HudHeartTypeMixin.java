package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.gui.hud.InGameHud.class)
public abstract abstract class HudHeartTypeMixin {}
