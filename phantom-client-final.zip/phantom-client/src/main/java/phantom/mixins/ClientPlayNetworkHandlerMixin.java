package phantom.mixins;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import phantom.Phantom;
import phantom.events.impl.PacketSendEvent;
@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
    @Inject(at=@At("HEAD"), method="sendPacket(Lnet/minecraft/network/packet/Packet;)V", cancellable=true)
    private void onSendPacket(Packet<?> packet, CallbackInfo ci){
        if(Phantom.INSTANCE==null)return;
        PacketSendEvent e=Phantom.INSTANCE.eventHandler.dispatchPacketSend(packet);
        if(e.isCancelled()) ci.cancel();
    }
}
