package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.entity.projectile.FishingBobberEntity.class)
public abstract abstract class FishingBobberEntityMixin {}
