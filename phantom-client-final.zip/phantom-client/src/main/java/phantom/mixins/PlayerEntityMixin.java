package phantom.mixins;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import phantom.Phantom;
import phantom.events.impl.AttackEntityEvent;
@Mixin(PlayerEntity.class)
public class PlayerEntityMixin {
    @Inject(at=@At("HEAD"), method="attack", cancellable=true)
    private void onAttack(net.minecraft.entity.Entity target, CallbackInfo ci){
        if(Phantom.INSTANCE==null)return;
        AttackEntityEvent e=Phantom.INSTANCE.eventHandler.dispatchAttackEntity(target);
        if(e.isCancelled()) ci.cancel();
    }
}
