package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.gui.screen.TitleScreen.class)
public abstract abstract class TitleScreenMixin {}
