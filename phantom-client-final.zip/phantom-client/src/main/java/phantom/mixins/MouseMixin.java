package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.Mouse.class)
public abstract abstract class MouseMixin {}
