package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.entity.MobEntityRenderer.class)
public abstract abstract class HumanoidMobRendererMixin {}
