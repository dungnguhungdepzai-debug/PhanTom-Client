package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.world.ClientWorld.class)
public abstract abstract class ClientExplosionTrackerMixin {}
