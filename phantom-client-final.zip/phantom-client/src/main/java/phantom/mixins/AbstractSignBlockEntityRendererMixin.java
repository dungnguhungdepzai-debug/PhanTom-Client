package phantom.mixins;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(net.minecraft.client.render.block.entity.SignBlockEntityRenderer.class)
public abstract abstract class AbstractSignBlockEntityRendererMixin {}
