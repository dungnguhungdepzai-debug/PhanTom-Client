package phantom.utils.font;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public class FontRenderer {
    private final String fontName;
    private final int size;
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public FontRenderer(String fontName, int size) {
        this.fontName = fontName;
        this.size     = size;
    }

    public void drawString(DrawContext ctx, String text, float x, float y, int color) {
        ctx.drawTextWithShadow(mc.textRenderer, text, (int)x, (int)y, color);
    }

    public float getStringWidth(String text) {
        return mc.textRenderer.getWidth(text);
    }

    public float getStringHeight() {
        return mc.textRenderer.fontHeight;
    }
}
