package phantom.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;

public interface IMinecraft {
    MinecraftClient      mc    = MinecraftClient.getInstance();
    default ClientPlayerEntity player() { return mc.player; }
    default ClientWorld        world()  { return mc.world;  }
}
