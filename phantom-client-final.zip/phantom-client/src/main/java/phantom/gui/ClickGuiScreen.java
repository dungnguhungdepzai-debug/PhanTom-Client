package phantom.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import phantom.Phantom;
import phantom.modules.Module;
import phantom.settings.Setting;
import phantom.settings.impl.*;

import java.util.*;

/**
 * Phantom ClickGui — dark purple theme
 * Left click  : toggle module
 * Right click : open settings panel
 * Scroll      : scroll module list inside panel
 * Drag        : move panels
 */
public class ClickGuiScreen extends Screen {

    // --- constants ---
    private static final int PANEL_W    = 140;
    private static final int HEADER_H   = 20;
    private static final int MODULE_H   = 18;
    private static final int SETTING_H  = 16;
    private static final int GAP        = 6;

    private static final int COL_BG        = 0xE8080812;
    private static final int COL_HEADER    = 0xFF12122A;
    private static final int COL_MOD_BG    = 0xFF0D0D1F;
    private static final int COL_MOD_HOVER = 0xFF1C1C3A;
    private static final int COL_ENABLED   = 0xFF9955FF;
    private static final int COL_DISABLED  = 0xFF555577;
    private static final int COL_TEXT      = 0xFFCCCCEE;
    private static final int COL_ACCENT    = 0xFF9955FF;
    private static final int COL_SET_BG    = 0xFF0A0A18;
    private static final int COL_SET_HOVER = 0xFF151530;
    private static final int COL_BORDER    = 0xFF2A2A55;

    // --- panel state ---
    private static class Panel {
        Module.Category category;
        int x, y;
        int scrollOffset = 0;
        boolean collapsed = false;
        boolean dragging   = false;
        boolean wasDragged = false;
        int dragDx, dragDy;

        // settings expansion
        Module expandedModule = null;

        Panel(Module.Category cat, int x, int y) {
            this.category = cat;
            this.x = x;
            this.y = y;
        }

        int totalHeight(List<Module> mods) {
            if (collapsed) return HEADER_H;
            int h = HEADER_H;
            for (Module m : mods) {
                if (!m.isVisible()) continue;
                h += MODULE_H;
                if (m == expandedModule) h += settingRows(m) * SETTING_H + 2;
            }
            return h;
        }

        private int settingRows(Module m) {
            return m.getSettings().size();
        }
    }

    private final List<Panel> panels = new ArrayList<>();
    private Panel activePanel = null;

    // search
    private String searchQuery = "";
    private boolean searchFocused = false;

    public ClickGuiScreen() {
        super(Text.literal("Phantom"));
    }

    @Override
    protected void init() {
        panels.clear();
        Module.Category[] cats = Module.Category.values();
        int x = GAP;
        for (Module.Category cat : cats) {
            panels.add(new Panel(cat, x, GAP + 30));
            x += PANEL_W + GAP;
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // dim background
        ctx.fillGradient(0, 0, this.width, this.height, 0xCC000008, 0xCC000020);

        // watermark bar
        ctx.fill(0, 0, this.width, 22, 0xEE060610);
        drawBorder(ctx, 0, 0, this.width, 22, COL_BORDER);
        ctx.drawTextWithShadow(this.textRenderer, "Phantom v1.0", 6, 7, COL_ACCENT);
        ctx.drawTextWithShadow(this.textRenderer, "Click GUI", this.width / 2 - this.textRenderer.getWidth("Click GUI") / 2, 7, COL_TEXT);

        // search bar
        int sbW = 120, sbH = 14, sbX = this.width - sbW - 8, sbY = 4;
        ctx.fill(sbX, sbY, sbX + sbW, sbY + sbH, COL_MOD_BG);
        drawBorder(ctx, sbX, sbY, sbX + sbW, sbY + sbH, searchFocused ? COL_ACCENT : COL_BORDER);
        String placeholder = searchQuery.isEmpty() ? "Search..." : searchQuery;
        int phColor = searchQuery.isEmpty() ? 0xFF444466 : COL_TEXT;
        ctx.drawTextWithShadow(this.textRenderer, placeholder, sbX + 4, sbY + 3, phColor);

        // panels
        for (Panel p : panels) {
            renderPanel(ctx, p, mouseX, mouseY);
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    private void renderPanel(DrawContext ctx, Panel panel, int mx, int my) {
        List<Module> mods = filteredMods(panel.category);
        int totalH = panel.totalHeight(mods);

        // outer border
        drawBorder(ctx, panel.x - 1, panel.y - 1, panel.x + PANEL_W + 1, panel.y + totalH + 1, COL_BORDER);

        // header
        ctx.fill(panel.x, panel.y, panel.x + PANEL_W, panel.y + HEADER_H, COL_HEADER);
        boolean headerHover = mx >= panel.x && mx <= panel.x + PANEL_W && my >= panel.y && my <= panel.y + HEADER_H;
        if (headerHover) ctx.fill(panel.x, panel.y, panel.x + PANEL_W, panel.y + HEADER_H, 0x22FFFFFF);

        // accent bar on left
        ctx.fill(panel.x, panel.y, panel.x + 2, panel.y + HEADER_H, COL_ACCENT);

        String catName = panel.category.name;
        ctx.drawTextWithShadow(this.textRenderer, catName, panel.x + 8, panel.y + 6, COL_ACCENT);

        // collapse indicator
        String arrow = panel.collapsed ? "+" : "-";
        ctx.drawTextWithShadow(this.textRenderer, arrow, panel.x + PANEL_W - 10, panel.y + 6, COL_TEXT);

        if (panel.collapsed) return;

        // module list
        int y = panel.y + HEADER_H;
        for (Module m : mods) {
            if (!m.isVisible()) continue;

            boolean hover = mx >= panel.x && mx <= panel.x + PANEL_W && my >= y && my <= y + MODULE_H;
            int bgColor = hover ? COL_MOD_HOVER : COL_MOD_BG;
            ctx.fill(panel.x, y, panel.x + PANEL_W, y + MODULE_H, bgColor);

            // enabled indicator dot
            int dotColor = m.isEnabled() ? COL_ENABLED : COL_DISABLED;
            ctx.fill(panel.x + 4, y + 7, panel.x + 8, y + 11, dotColor);

            // glow bar if enabled
            if (m.isEnabled()) {
                ctx.fill(panel.x, y, panel.x + 2, y + MODULE_H, COL_ENABLED);
            }

            int textColor = m.isEnabled() ? COL_TEXT : 0xFF666688;
            ctx.drawTextWithShadow(this.textRenderer, m.getName(), panel.x + 12, y + 5, textColor);

            // right-click settings indicator
            if (!m.getSettings().isEmpty()) {
                String ind = m == panel.expandedModule ? "v" : ">";
                ctx.drawTextWithShadow(this.textRenderer, ind, panel.x + PANEL_W - 10, y + 5, 0xFF444466);
            }

            y += MODULE_H;

            // settings rows
            if (m == panel.expandedModule) {
                y = renderSettings(ctx, m, panel, y, mx, my);
            }
        }
    }

    private int renderSettings(DrawContext ctx, Module m, Panel panel, int y, int mx, int my) {
        for (Setting<?> s : m.getSettings()) {
            boolean hover = mx >= panel.x && mx <= panel.x + PANEL_W && my >= y && my <= y + SETTING_H;
            ctx.fill(panel.x, y, panel.x + PANEL_W, y + SETTING_H, hover ? COL_SET_HOVER : COL_SET_BG);
            ctx.fill(panel.x, y, panel.x + 1, y + SETTING_H, 0xFF333355);

            String label = s.getName();
            String value = s.getValueString();
            ctx.drawTextWithShadow(this.textRenderer, label, panel.x + 6, y + 4, 0xFF8888AA);

            int vw = this.textRenderer.getWidth(value);
            int vColor = (s instanceof BooleanSetting b)
                ? (b.isEnabled() ? COL_ENABLED : 0xFF555577)
                : 0xFFAABBCC;
            ctx.drawTextWithShadow(this.textRenderer, value, panel.x + PANEL_W - vw - 4, y + 4, vColor);

            // number setting: draw bar
            if (s instanceof NumberSetting n) {
                int barX = panel.x + 6;
                int barY = y + SETTING_H - 3;
                int barW = PANEL_W - 12;
                double pct = (n.getValue() - n.getMin()) / (n.getMax() - n.getMin());
                ctx.fill(barX, barY, barX + barW, barY + 2, 0xFF222244);
                ctx.fill(barX, barY, barX + (int)(barW * pct), barY + 2, COL_ACCENT);
            }

            y += SETTING_H;
        }
        // bottom separator
        ctx.fill(panel.x, y, panel.x + PANEL_W, y + 2, 0xFF0A0A1A);
        return y + 2;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int btn) {
        int mx = (int) mouseX, my = (int) mouseY;

        // search bar click
        int sbW = 120, sbH = 14, sbX = this.width - sbW - 8, sbY = 4;
        if (mx >= sbX && mx <= sbX + sbW && my >= sbY && my <= sbY + sbH) {
            searchFocused = true;
            return true;
        }
        searchFocused = false;

        for (Panel p : panels) {
            List<Module> mods = filteredMods(p.category);

            // header
            if (mx >= p.x && mx <= p.x + PANEL_W && my >= p.y && my <= p.y + HEADER_H) {
                if (btn == 0) {
                    // Collapse only toggled on release (see mouseReleased); here just arm drag
                    p.dragging   = true;
                    p.wasDragged = false;
                    p.dragDx     = mx - p.x;
                    p.dragDy     = my - p.y;
                    activePanel  = p;
                }
                return true;
            }

            if (p.collapsed) continue;

            int y = p.y + HEADER_H;
            for (Module m : mods) {
                if (!m.isVisible()) continue;
                if (mx >= p.x && mx <= p.x + PANEL_W && my >= y && my <= y + MODULE_H) {
                    if (btn == 0) m.toggle();
                    if (btn == 1) p.expandedModule = (p.expandedModule == m) ? null : m;
                    return true;
                }
                y += MODULE_H;

                if (m == p.expandedModule) {
                    for (Setting<?> s : m.getSettings()) {
                        if (mx >= p.x && mx <= p.x + PANEL_W && my >= y && my <= y + SETTING_H) {
                            handleSettingClick(s, mx, p, btn);
                            return true;
                        }
                        y += SETTING_H;
                    }
                    y += 2;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, btn);
    }

    private void handleSettingClick(Setting<?> s, int mx, Panel p, int btn) {
        if (s instanceof BooleanSetting b) {
            b.toggle();
        } else if (s instanceof ModeSetting m) {
            if (btn == 0) m.cycle();
            else { List<String> opts = m.getOptions(); int idx = opts.indexOf(m.getValue()); m.setValue(opts.get((idx - 1 + opts.size()) % opts.size())); }
        } else if (s instanceof NumberSetting n) {
            int barX = p.x + 6;
            int barW = PANEL_W - 12;
            double pct = Math.max(0, Math.min(1, (double)(mx - barX) / barW));
            n.setValue(n.getMin() + pct * (n.getMax() - n.getMin()));
        }
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (activePanel != null && activePanel.dragging) {
            activePanel.wasDragged = true;
            activePanel.x = (int) mx - activePanel.dragDx;
            activePanel.y = (int) my - activePanel.dragDy;
            activePanel.x = Math.max(0, Math.min(this.width - PANEL_W, activePanel.x));
            activePanel.y = Math.max(22, Math.min(this.height - 40, activePanel.y));
            return true;
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        if (activePanel != null) {
            if (!activePanel.wasDragged) activePanel.collapsed = !activePanel.collapsed;
            activePanel.dragging = false;
            activePanel = null;
        }
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hScroll, double vScroll) {
        for (Panel p : panels) {
            List<Module> mods = filteredMods(p.category);
            int totalH = p.totalHeight(mods);
            if (mx >= p.x && mx <= p.x + PANEL_W && my >= p.y && my <= p.y + totalH) {
                p.scrollOffset = (int) Math.max(0, p.scrollOffset - vScroll * 10);
                return true;
            }
        }
        return super.mouseScrolled(mx, my, hScroll, vScroll);
    }

    @Override
    public boolean charTyped(char chr, int mod) {
        if (searchFocused) {
            searchQuery += chr;
            return true;
        }
        return super.charTyped(chr, mod);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mod) {
        if (searchFocused) {
            if (key == 259 && !searchQuery.isEmpty()) // BACKSPACE
                searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
            if (key == 256) searchFocused = false; // ESCAPE
            return true;
        }
        if (key == 256) { this.client.setScreen(null); return true; }
        return super.keyPressed(key, scan, mod);
    }

    private List<Module> filteredMods(Module.Category cat) {
        var all = Phantom.INSTANCE.moduleManager.getByCategory(cat);
        if (searchQuery.isEmpty()) return all;
        String q = searchQuery.toLowerCase();
        return all.stream().filter(m -> m.getName().toLowerCase().contains(q)).toList();
    }

    private void drawBorder(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        ctx.fill(x1, y1, x2, y1 + 1, color);
        ctx.fill(x1, y2 - 1, x2, y2, color);
        ctx.fill(x1, y1, x1 + 1, y2, color);
        ctx.fill(x2 - 1, y1, x2, y2, color);
    }

    @Override
    public boolean shouldPause() { return false; }
}
